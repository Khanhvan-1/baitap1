package com.example.androidcoban;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MayTinhActivity extends AppCompatActivity {

    EditText edtSoA, edtSoB;
    TextView tvKetQua;
    Button btnCong, btnTru, btnNhan, btnChia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_may_tinh);
        initControl();
    }

    private void initControl() {
        edtSoA = findViewById(R.id.edtSoA);
        edtSoB = findViewById(R.id.edtSoB);
        tvKetQua = findViewById(R.id.tvKetQua);
        btnCong = findViewById(R.id.btnCong);
        btnTru = findViewById(R.id.btnTru);
        btnNhan = findViewById(R.id.btnNhan);
        btnChia = findViewById(R.id.btnChia);

        View.OnClickListener listener = v -> {
            try {
                double a = Double.parseDouble(edtSoA.getText().toString());
                double b = Double.parseDouble(edtSoB.getText().toString());
                double kq = 0;

                if (v.getId() == R.id.btnCong) {
                    kq = a + b;
                } else if (v.getId() == R.id.btnTru) {
                    kq = a - b;
                } else if (v.getId() == R.id.btnNhan) {
                    kq = a * b;
                } else if (v.getId() == R.id.btnChia) {
                    if (b == 0) {
                        tvKetQua.setText("Không thể chia cho 0!");
                        return;
                    }
                    kq = a / b;
                }
                tvKetQua.setText("Kết quả: " + kq);

            } catch (Exception e) {
                tvKetQua.setText("⚠️ Vui lòng nhập số hợp lệ!");
            }
        };

        btnCong.setOnClickListener(listener);
        btnTru.setOnClickListener(listener);
        btnNhan.setOnClickListener(listener);
        btnChia.setOnClickListener(listener);
    }
}
