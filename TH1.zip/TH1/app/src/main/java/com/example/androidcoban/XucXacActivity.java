package com.example.androidcoban;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import java.util.Random;

public class XucXacActivity extends AppCompatActivity {

    private Button btnRoll;
    private ImageView imgDice;
    private TextView tvResult;
    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xuc_xac);

        // Ánh xạ view
        btnRoll = findViewById(R.id.btnRoll);
        imgDice = findViewById(R.id.imgDice);
        tvResult = findViewById(R.id.tvResult);

        // Xử lý sự kiện bấm nút
        btnRoll.setOnClickListener(v -> {
            int so = random.nextInt(6) + 1; // random 1–6

            // Hiển thị kết quả
            tvResult.setText("🎲 Kết quả: " + so);

            // Gán hình xúc xắc tương ứng
            switch (so) {
                case 1:
                    imgDice.setImageResource(R.drawable.dice1);
                    break;
                case 2:
                    imgDice.setImageResource(R.drawable.dice2);
                    break;
                case 3:
                    imgDice.setImageResource(R.drawable.dice3);
                    break;
                case 4:
                    imgDice.setImageResource(R.drawable.dice4);
                    break;
                case 5:
                    imgDice.setImageResource(R.drawable.dice5);
                    break;
                case 6:
                    imgDice.setImageResource(R.drawable.dice6);
                    break;
            }
        });
    }
}
