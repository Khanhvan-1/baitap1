package com.example.androidcoban;

import android.app.role.RoleManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnMayTinh, btnXucXac, btnLienLac, btnCamera;
    private boolean isRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Gán view
        btnMayTinh = findViewById(R.id.btnMayTinh);
        btnXucXac = findViewById(R.id.btnXucXac);
        btnLienLac = findViewById(R.id.btnLienLac);
        btnCamera = findViewById(R.id.btnCamera);

        // Lưu user (demo)
        SharedPreferences prefs = getSharedPreferences("user_session", MODE_PRIVATE);
        String username = prefs.getString("username", "Người dùng");

        // Điều hướng
        btnMayTinh.setOnClickListener(v -> startActivity(new Intent(this, MayTinhActivity.class)));
        btnXucXac.setOnClickListener(v -> startActivity(new Intent(this, XucXacActivity.class)));
        btnLienLac.setOnClickListener(v -> startActivity(new Intent(this, LienLacActivity.class)));
        btnCamera.setOnClickListener(v -> startActivity(new Intent(this, CameraActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        isRunning = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        isRunning = false;
    }
}
