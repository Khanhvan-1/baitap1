package com.example.androidcoban;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;

public class LienLacActivity extends AppCompatActivity {
    EditText edtPhone;
    Button btnCall, btnSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lien_lac);

        edtPhone = findViewById(R.id.edtPhone);
        btnCall = findViewById(R.id.btnCall);
        btnSms = findViewById(R.id.btnSms);

        btnCall.setOnClickListener(v -> {
            String sdt = edtPhone.getText().toString();
            if (sdt.isEmpty()) {
                Toast.makeText(this, "Nhập số điện thoại!", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + sdt));
            startActivity(i);
        });

        btnSms.setOnClickListener(v -> {
            String sdt = edtPhone.getText().toString();
            if (sdt.isEmpty()) {
                Toast.makeText(this, "Nhập số điện thoại!", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + sdt));
            i.putExtra("sms_body", "Xin chào!");
            startActivity(i);
        });
    }
}
